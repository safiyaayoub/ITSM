from . import ir_ui_view
from . import ir_act_window_view
