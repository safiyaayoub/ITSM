Request name in title displayed as `h2` instead of `h1` as before
