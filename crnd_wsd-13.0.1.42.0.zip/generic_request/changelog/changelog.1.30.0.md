Merge `generic_request_priority` into core (`generic_request`)
