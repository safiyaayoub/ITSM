Added ability to assign multiple requests with a single operations.
Just select requests from list view and call context action *Assign*.
