- Change UI of request form view to be consistent with frontend and other places.
  This change allows to select category before request type on request creation.
- Move *Request Events* stat-buttons to separate *Technical* page
