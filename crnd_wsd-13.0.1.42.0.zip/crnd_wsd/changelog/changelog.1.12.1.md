Fix display of avatars for portal users
