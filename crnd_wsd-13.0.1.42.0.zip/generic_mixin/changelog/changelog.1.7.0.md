Changed `generic.mixin.name_with_code`: generate new code only if record
is not saved yet
